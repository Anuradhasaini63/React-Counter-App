import { useState } from 'react'
import './output.css'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  const add = ()=> {
    setCount(count+1)
  }

  const minus = ()=> {
    setCount(count - 1)
  }
  const del = ()=> {
    setCount(0)
  }

  return (
    <>
       <div className='bg-gray-900 p-3 rounded-sm'>
       <button className='border-none py-2 px-4 bg-gray-300 m-2' onClick={add}>+</button>
        <span className=' text-white'>{count}</span>
        <button className='border-none py-2 px-4 bg-gray-300 m-2' onClick={minus}>-</button>
        <button className='border-none py-2 px-4 bg-gray-300 m-2' onClick={del}>Del</button>
       </div>
    </>
  )
}

export default App
